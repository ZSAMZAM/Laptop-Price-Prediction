# Streamlit app for Laptop Price Prediction
# App loogu talagalay saadaalinta qiimaha laptop-ka

import streamlit as st
import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression

# -------------------------------
# Load dataset
# Soo gelinta dataset-ka
# -------------------------------

df = pd.read_csv("../data/laptop_price.csv", encoding="latin1")

# One-hot encoding
# U bedelidda xogta qoraalka ah tirooyin
df_encoded = pd.get_dummies(df, drop_first=True)

# Split features and target
# Kala saarida input (X) iyo output (Price)
X = df_encoded.drop("Price_euros", axis=1)
y = df_encoded["Price_euros"]


# Train model
# Tababaridda regression model-ka
model = LinearRegression()
model.fit(X, y)

# -------------------------------
# Streamlit UI
# Interface-ka isticmaalaha
# -------------------------------

st.title("💻 Laptop Price Prediction App")
st.write(
    "This app predicts laptop prices based on hardware specifications.\n\n"
    "App-kan wuxuu saadaalinayaa qiimaha laptop-ka iyadoo lagu saleynayo specs-ka."
)

# User inputs
# Gelinta xogta isticmaalaha

ram = st.number_input("RAM (GB)", min_value=2, max_value=64, value=8)
weight = st.number_input("Weight (kg)", min_value=0.5, max_value=5.0, value=2.0)
screen = st.number_input("Screen Size (inches)", min_value=10.0, max_value=18.0, value=15.6)

# Create input dataframe
# Abuur dataframe cusub oo user-ka ah
input_data = pd.DataFrame({
    "Ram": [ram],
    "Weight": [weight],
    "Inches": [screen]
})

# Align columns with training data
# Hubinta in columns-ku la mid yihiin kuwii model-ka
input_data = input_data.reindex(columns=X.columns, fill_value=0)

# Prediction
# Saadaalin
if st.button("Predict Price"):
    prediction = model.predict(input_data)
    st.success(f"💰 Estimated Laptop Price: {prediction[0]:,.2f}")
